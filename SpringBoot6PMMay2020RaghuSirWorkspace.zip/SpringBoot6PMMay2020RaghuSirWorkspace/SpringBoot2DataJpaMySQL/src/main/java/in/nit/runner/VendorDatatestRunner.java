package in.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nit.repo.VendorRepo;

@Component
public class VendorDatatestRunner implements CommandLineRunner {
	@Autowired
	private VendorRepo repo;

	@Override
	public void run(String... args) throws Exception {
		//Vendor v=repo.getDetails("AAD");	System.out.println(v);
		
		//String s=repo.getDetailsA("AAD");		System.out.println(s);
		
		Object ob=repo.getDetailsB("AAD");
		Object[] arr=(Object[])ob;
		System.out.println(arr[0]+"-"+arr[1]);
	}

}




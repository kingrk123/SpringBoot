package in.nit.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.nit.model.Vendor;

public interface VendorRepo extends JpaRepository<Vendor, Integer>{
	
	//@Query("select v from Vendor v where v.venCode!=:venCode") //Exception
	@Query("select v from Vendor v where v.venCode=:venCode") //Fine
	Vendor getDetails(String venCode);
	
	@Query("select v.venName from Vendor v where v.venCode=:venCode") //Fine
	String getDetailsA(String venCode);
	
	//internally Object[] but upcasted to java.lang.Object to return as one value
	@Query("select v.venId,v.venName from Vendor v where v.venCode=:venCode") //Fine
	Object getDetailsB(String venCode); 

}



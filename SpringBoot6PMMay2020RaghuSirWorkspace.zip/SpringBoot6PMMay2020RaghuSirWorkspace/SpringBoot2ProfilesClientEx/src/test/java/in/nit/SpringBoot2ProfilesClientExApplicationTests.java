package in.nit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot2ProfilesClientExApplicationTests {

	@Test
	void contextLoads() {
	}

}

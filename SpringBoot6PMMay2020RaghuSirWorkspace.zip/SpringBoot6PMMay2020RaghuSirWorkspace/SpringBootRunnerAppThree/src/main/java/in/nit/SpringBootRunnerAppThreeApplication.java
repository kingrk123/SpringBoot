package in.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRunnerAppThreeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRunnerAppThreeApplication.class, args);
	}

}

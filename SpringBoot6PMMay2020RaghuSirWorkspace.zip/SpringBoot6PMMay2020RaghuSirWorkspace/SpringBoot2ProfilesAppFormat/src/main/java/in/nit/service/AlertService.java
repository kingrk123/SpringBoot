package in.nit.service;

public interface AlertService {

	public void showAlert();
}

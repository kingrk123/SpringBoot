package in.nit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import in.nit.model.Product;
import in.nit.service.IProductService;
import in.nit.validator.ProductValidator;

@Controller
@RequestMapping("/product")
public class ProductController {
	@Autowired
	private ProductValidator validator;

	@Autowired
	private IProductService service;

	//1. Display Register page
	@RequestMapping("/register")
	public String showPage(Model model) {
		//Form Backing Object
		model.addAttribute("product", new Product());
		return "ProductRegister";
	}

	//2. Read Form data as ModelAttribute and save
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveData(
			@ModelAttribute Product product, 
			Errors errors,	
			Model model
			) 
	{
		//call before save operation
		validator.validate(product, errors);

		if(!errors.hasErrors()) { //no errors
			Integer id=service.saveProduct(product);
			String msg="Product '"+id+"' saved";
			model.addAttribute("message", msg);
			model.addAttribute("product", new Product());
		}else { //errors exist
			model.addAttribute("message", "Please check All Errors!");
		}

		//Goto UI Page back
		return "ProductRegister";
	}

	//3. Fetch all records from DB and display at UI
	@RequestMapping("/all")
	public String fetchAll(Model model) {
		//read data from DB
		List<Product> list= service.getAllProducts();
		//send data to UI
		model.addAttribute("list", list);
		return "ProductData";
	}

	//4. Delete row by Id   .../delete?pid=10
	@RequestMapping("/delete")
	public String deleteOne(
			@RequestParam("pid")Integer id,
			Model model
			) 
	{
		service.deleteProduct(id);
		model.addAttribute("message", "Product '"+id+"' Deleted");
		//send remaining data
		//read data from DB
		List<Product> list= service.getAllProducts();
		//send data to UI
		model.addAttribute("list", list);
		return "ProductData";
	}

	//5. show edit page with data
	@RequestMapping("/edit")
	public String showEdit(
			@RequestParam("pid")Integer id,
			Model model
			)
	{
		Product p=service.getOneProduct(id);
		//send data to UI and fill in HTML FORM
		model.addAttribute("product", p);
		return "ProductEdit";
	}

	//6. Update Product
	@RequestMapping(value = "/update",method = RequestMethod.POST)
	public String updateOne(
			@ModelAttribute Product product,
			Model model
			) 
	{
		service.updateProduct(product);
		//send data to UI
		model.addAttribute("message", "Product '"+product.getProdId()+"' Updated");
		//send othre data
		List<Product> list=service.getAllProducts();
		model.addAttribute("list", list);
		return "ProductData";
	}



}
package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.collection.Student;
import in.nareshit.raghu.repo.StudentRepository;

@Component
public class StudentRunner implements CommandLineRunner {
	@Autowired
	private StudentRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		repo.deleteAll();
		
		Student s=repo.save(new Student(101, "SAM", 30.25));
		repo.save(new Student(102, "ANAND", 40.25));
		repo.save(new Student(101, "CHINTU", 50.25));
		
		System.out.println(s.getId());
		
		//---------------------------
		repo.findAll().forEach(System.out::println);
		
	}

}

package in.nareshit.raghu.collection;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Document //convert object as JSON Format
public class Student {
	@Id //PK - Value Generated in Hexa Decimal Format
	private String id; 
	
	@NonNull
	private Integer stdId;
	@NonNull
	private String stdName;
	@NonNull
	private Double stdFee;
	
}

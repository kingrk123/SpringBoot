package in.nareshit.raghu.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import in.nareshit.raghu.collection.Student;

public interface StudentRepository 
	extends MongoRepository<Student, String> {

}

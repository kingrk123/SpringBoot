package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Employee;
import in.nareshit.raghu.repo.EmployeeRepository;

@Component
public class EmployeeRunner implements CommandLineRunner {
	@Autowired
	private EmployeeRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		repo.deleteAll();
		
		repo.save(new Employee(10, "DEV", 60.25));
		repo.save(new Employee(11, "SAM", 66.25));
		repo.save(new Employee(12, "KHAN", 68.25));
		
		repo.findAll().forEach(System.out::println);
	}

}

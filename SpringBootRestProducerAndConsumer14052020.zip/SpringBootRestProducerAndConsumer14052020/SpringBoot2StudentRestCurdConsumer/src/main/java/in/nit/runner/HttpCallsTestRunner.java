package in.nit.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class HttpCallsTestRunner 
implements CommandLineRunner
{

	@Override
	public void run(String... args) throws Exception {
		String url="http://localhost:9898/student/update";

		RestTemplate rt=new RestTemplate();

		HttpHeaders header=new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		
		String body="{\"stdId\":10,\"stdName\": \"SAM-AA\",\"stdFee\": 88.88,\"stdCourse\": \"HIB\"}";
		HttpEntity<String> req=new HttpEntity<String>(body,header);
		
		//rt.put(url, req);
		ResponseEntity<String> resp=rt.exchange(url, HttpMethod.PUT, req, String.class);
		
		System.out.println(resp.getBody());
		System.out.println(resp.getStatusCodeValue());
		System.out.println(resp.getStatusCode().name());
		
		
		System.exit(0); //stop server 
	}
}






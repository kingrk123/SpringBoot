package in.nit.model;

import lombok.Data;

@Data
public class Student {
	private Integer stdId;
	
	private String stdName;
	
	private Double stdFee;
	
	private String stdCourse;
}



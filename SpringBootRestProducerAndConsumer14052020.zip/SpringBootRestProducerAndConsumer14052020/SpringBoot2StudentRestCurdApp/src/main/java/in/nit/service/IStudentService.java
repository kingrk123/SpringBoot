package in.nit.service;

import java.util.List;

import in.nit.model.Student;

public interface IStudentService {

	Integer saveStudent(Student s);
	List<Student> findAllStudents();
	Student findOneStudent(Integer id);
	void deleteStudent(Integer id);
	void updateStudent(Student s);
	boolean isStudentExist(Integer id);
	
}

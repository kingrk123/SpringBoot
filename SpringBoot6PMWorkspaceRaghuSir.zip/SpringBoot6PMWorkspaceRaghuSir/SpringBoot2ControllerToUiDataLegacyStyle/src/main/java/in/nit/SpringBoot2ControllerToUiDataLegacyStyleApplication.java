package in.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot2ControllerToUiDataLegacyStyleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot2ControllerToUiDataLegacyStyleApplication.class, args);
	}

}

package in.nit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot2StarterConfigTestApplicationTests {

	@Test
	void contextLoads() {
	}

}

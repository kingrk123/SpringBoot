package in.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootInputsExTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootInputsExTwoApplication.class, args);
	}

}

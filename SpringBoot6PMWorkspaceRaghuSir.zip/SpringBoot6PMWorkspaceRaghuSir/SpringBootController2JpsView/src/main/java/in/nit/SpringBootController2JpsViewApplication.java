package in.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootController2JpsViewApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootController2JpsViewApplication.class, args);
	}

}

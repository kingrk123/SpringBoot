package in.nit.config;

//Spring Java Based Config File..
//@Configuration
public class AppConfig {
	
}

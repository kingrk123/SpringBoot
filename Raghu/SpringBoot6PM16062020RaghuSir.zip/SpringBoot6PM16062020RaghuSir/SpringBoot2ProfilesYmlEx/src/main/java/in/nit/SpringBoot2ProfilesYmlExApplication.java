package in.nit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot2ProfilesYmlExApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot2ProfilesYmlExApplication.class, args);
	}

}

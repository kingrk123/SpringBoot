export class Product {
  prodId : number;
  prodCode : string;
  prodCost : number;
  prodDiscount : number;
  prodGst : number;
}

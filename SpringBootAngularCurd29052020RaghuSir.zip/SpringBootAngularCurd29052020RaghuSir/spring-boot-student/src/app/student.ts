export class Student {
    stdId : number;
    stdName : string;
    stdFee : number;
    stdCourse : string;
}

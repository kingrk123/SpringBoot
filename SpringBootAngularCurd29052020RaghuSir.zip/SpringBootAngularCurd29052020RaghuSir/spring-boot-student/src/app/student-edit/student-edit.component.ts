import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Student } from '../student';

@Component({
  selector: 'app-student-edit',
  templateUrl: './student-edit.component.html',
  styleUrls: ['./student-edit.component.css']
})
export class StudentEditComponent implements OnInit {

   student : Student = new Student();
   id : number;

  constructor(private service:StudentService,private activatedRoute:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    //read ID given by List Component on click Edit
    this.id=this.activatedRoute.snapshot.params['id'];
    //call service and subscribe success data to student
    this.service.getOneStudent(this.id).subscribe(
      data=>{
        this.student=data;
      }
    );
  }

  updateStudent(){
    //console.log('Update Req');
    this.service.updateStudent(this.student)
    .subscribe(
      data=>{
        console.log(data);
        this.router.navigate(['all']);
      }
    );
  }

}

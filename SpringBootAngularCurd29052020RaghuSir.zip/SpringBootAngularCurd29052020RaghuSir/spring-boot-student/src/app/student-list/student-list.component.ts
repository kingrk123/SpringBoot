import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';
import { Student } from '../student';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {

  students: Student[];
  message: any;

  constructor(private service: StudentService, private router: Router) { }

  ngOnInit(): void {
    /**Load On Start up */
    this.getAllStudents();
  }

  getAllStudents() {
    /**This method call service, get data from Observable
     * and copy into students array (subscribe)
     */
    this.service.getAllStudents().subscribe(
      data => {
        //on success
        this.students = data;
      },
      error => {
        //on fail
        console.log(error);
      }
    );
  }

  deleteStudent(id: number) {
    console.log('deleted' + id);
    this.service.deleteStudent(id).subscribe(
      data => {
        console.log(data);
        this.message = data;
        this.getAllStudents();
      },
      error => {
        console.log(error);
      }
    );
  }

  showEdit(id : number){
    //moving to Edit Component
    this.router.navigate(['edit',id]);
  }

}
